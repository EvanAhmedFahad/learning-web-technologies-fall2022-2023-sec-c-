<style type='text/css'>
   .myDivcenter {
  border: 0px outset black;
  background-color: white;    
  text-align: center;
} 
  </style>

<div class="myDivcenter">

<nav class="  bg-secondary">

<?php
echo "Copyright ©" .date("Y"), " All rights reserved";
?><br>
</div>


   