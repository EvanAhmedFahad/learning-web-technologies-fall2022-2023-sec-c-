<html> 
<head>  
<title>View Admission Panel</title>
</head>
<body style="background-color:LavenderBlush;">

<div class="menu">
<?php require 'Navbar.php';?>
</div>

<img src="bd.jpg" style="width:1536px;height:566px;"></h1>

<div class="menu">
<?php include 'footer.php';?>
</div>

</body>
</html>