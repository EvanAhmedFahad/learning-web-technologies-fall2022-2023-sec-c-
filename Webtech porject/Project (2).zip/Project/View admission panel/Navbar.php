<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
<style >
#expand-box
{
    width: 100%;
    border: 0px outset black;
    
}

#expand-box-header
{
    background-color: bg-light;
    margin: 1;
    color: black;
    padding: 0 9 9px 9px;
}
.clear{
    clear:both;
}
</style>

<nav class="navbar navbar-expand-sm navbar-light bg-secondary">
    
<div id="expand-box">
   <div id="expand-box-header">
      
      <span style="float: left;"><h1><img src="Ez.jpg" alt="logo" style="width:90px;"></h1></span> <br>
      <span style="float: right;"><h2 style="font-size: 1.1em"> <?php
      echo  '<ul class="navbar-nav ml-auto">
      <li class="nav-item active">
       <a class="nav-link" href="http://localhost:8081/Project/View%20admission%20panel/ViewAdmissionPanel.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="http://localhost:8081/Project/Login/Login.php">Sign In</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="http://localhost:8081/Project/Registration%20with%20student%20information/View/RegistrationWithStudentInfo.php">Registration</a>
      </li>
      </ul>';
      ?> </div></h2></span><br><br><br>

  </div>
  </nav> 
  </div>

  <div class="clear"></div>
 
